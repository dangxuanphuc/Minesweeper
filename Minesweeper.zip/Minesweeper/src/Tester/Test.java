package Tester;

import Minesweeper.Game;

public class Test {
	public static void main(String[] args) {
		Game gui = new Game();
		gui.setVisible(true);
	}
}